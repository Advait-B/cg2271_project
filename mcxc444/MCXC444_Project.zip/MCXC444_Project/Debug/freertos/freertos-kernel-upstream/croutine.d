freertos/freertos-kernel-upstream/croutine.o \
 freertos/freertos-kernel-upstream/croutine.d: \
 ../freertos/freertos-kernel-upstream/croutine.c \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/FreeRTOS.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel\template/FreeRTOSConfig.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel\template\ARM_CM0/FreeRTOSConfig_Gen.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/projdefs.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/portable.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/deprecated_definitions.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\portable\GCC\ARM_CM0/portmacro.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/mpu_wrappers.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/task.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/list.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/croutine.h
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/FreeRTOS.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel\template/FreeRTOSConfig.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel\template\ARM_CM0/FreeRTOSConfig_Gen.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/projdefs.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/portable.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/deprecated_definitions.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\portable\GCC\ARM_CM0/portmacro.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/mpu_wrappers.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/task.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/list.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\freertos\freertos-kernel-upstream\include/croutine.h:
