drivers/fsl_smc.o drivers/fsl_smc.d: ../drivers/fsl_smc.c \
 ../drivers/fsl_smc.h ../drivers/fsl_common.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device/fsl_device_registers.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device/MCXC444.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_ADC.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device/MCXC444_COMMON.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\CMSIS/core_cm0plus.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\CMSIS/cmsis_version.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\CMSIS/cmsis_compiler.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\CMSIS/cmsis_gcc.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device/system_MCXC444.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device/MCXC444_features.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_CMP.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_DAC.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_DMA.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_DMAMUX.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_FGPIO.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_FLEXIO.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_FTFA.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_GPIO.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_I2C.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_I2S.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_LCD.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_LLWU.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_LPTMR.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_LPUART.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_MCG.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_MCM.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_MTB.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_MTBDWT.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_NV.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_OSC.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_PIT.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_PMC.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_PORT.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_RCM.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_RFSYS.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_ROM.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_RTC.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_SIM.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_SMC.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_SPI.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_TPM.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_UART.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_USB.h \
 C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_VREF.h \
 ../drivers/fsl_common_arm.h ../drivers/fsl_clock.h
../drivers/fsl_smc.h:
../drivers/fsl_common.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device/fsl_device_registers.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device/MCXC444.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_ADC.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device/MCXC444_COMMON.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\CMSIS/core_cm0plus.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\CMSIS/cmsis_version.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\CMSIS/cmsis_compiler.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\CMSIS/cmsis_gcc.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device/system_MCXC444.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device/MCXC444_features.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_CMP.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_DAC.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_DMA.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_DMAMUX.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_FGPIO.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_FLEXIO.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_FTFA.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_GPIO.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_I2C.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_I2S.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_LCD.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_LLWU.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_LPTMR.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_LPUART.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_MCG.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_MCM.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_MTB.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_MTBDWT.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_NV.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_OSC.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_PIT.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_PMC.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_PORT.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_RCM.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_RFSYS.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_ROM.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_RTC.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_SIM.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_SMC.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_SPI.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_TPM.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_UART.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_USB.h:
C:\Users\yikch\Downloads\MCUXpresso\MCXC444_Project\device\periph2/PERI_VREF.h:
../drivers/fsl_common_arm.h:
../drivers/fsl_clock.h:
